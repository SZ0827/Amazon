(function (root) {
  const sites = {'美国':'www.amazon.com','英国':'www.amazon.co.uk','德国':'www.amazon.de','法国':'www.amazon.fr','意大利':'www.amazon.it','西班牙':'www.amazon.es','加拿大':'www.amazon.ca','日本':'www.amazon.co.jp','澳大利亚':'www.amazon.com.au','印度':'www.amazon.in','墨西哥':'www.amazon.com.mx'};
  const labels = {unrated:'未标注',high:'高相关',low:'低相关',none:'不相关'};
  function parse(text) {
    return [...new Map(text.split(/[\r\n\t]+/).map(s=>s.trim()).filter(Boolean).map(s=>[s.toLocaleLowerCase(),s])).values()];
  }
  function searchURL(site, keyword) {
    if (!Object.values(sites).includes(site)) throw new Error('不支持的站点');
    return `https://${site}/s?k=${encodeURIComponent(keyword)}`;
  }
  function cell(value) {
    let s = String(value ?? '');
    if (/^[\s]*[=+@-]/.test(s)) s = "'" + s;
    return '"' + s.replaceAll('"','""') + '"';
  }
  function csv(items, site) {
    return '\uFEFF' + [['关键词','相关性','备注','站点','更新时间'], ...items.map(x=>[x.keyword,labels[x.rating],x.note,site,x.updatedAt])].map(r=>r.map(cell).join(',')).join('\r\n');
  }
  function nextUnrated(items, current) {
    for (let step=1;step<=items.length;step++) { const i=(current+step)%items.length; if(items[i].rating==='unrated') return i; }
    return -1;
  }
  const api={sites,labels,parse,searchURL,cell,csv,nextUnrated};
  if(typeof module!=='undefined') module.exports=api;
  else root.KeywordCore=api;
})(globalThis);
