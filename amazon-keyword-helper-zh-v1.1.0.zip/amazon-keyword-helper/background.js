chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:true}).catch(console.error);
// Translate in the service worker: remote services receive only the requested keyword.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'TRANSLATE_KEYWORD') return;
  const keyword = String(message.keyword || '').trim();
  if (!keyword || keyword.length > 400) { sendResponse({error:'关键词为空或过长'}); return; }
  (async () => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);
    try {
      const url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=zh-CN&dt=t&q='+encodeURIComponent(keyword);
      const res = await fetch(url, {signal:controller.signal,cache:'no-store'});
      if (!res.ok) throw Error('翻译服务 HTTP '+res.status);
      const data = await res.json();
      const translated = Array.isArray(data?.[0]) ? data[0].map(x => x?.[0] || '').join('').trim() : '';
      if (!translated) throw Error('翻译结果为空');
      sendResponse({translation:translated});
    } catch (e) {sendResponse({error:e.name==='AbortError'?'翻译请求超时':String(e.message||e)});}
    finally {clearTimeout(timeout);}
  })();
  return true;
});
