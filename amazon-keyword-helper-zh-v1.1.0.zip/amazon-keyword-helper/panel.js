'use strict';
const C=KeywordCore, $=id=>document.getElementById(id);
let state={items:[],current:0,site:'www.amazon.com',autoNext:true,translateEnabled:true}, page=0, searchTab=null, saveQueue=Promise.resolve(), busy=false;
let translations={}, translateQueue=Promise.resolve(), translationToken=0;
const PAGE_SIZE=60;
function status(message,error=false){$('status').textContent=message;$('status').classList.toggle('error',error);}
function save(){
  const snapshot=structuredClone(state);
  const job=saveQueue.catch(()=>{}).then(()=>chrome.storage.local.set({workspace:snapshot}));
  saveQueue=job;
  return job;
}
function current(){return state.items[state.current];}
function filtered(){const q=$('filterText').value.trim().toLocaleLowerCase(), r=$('filter').value;return state.items.map((item,index)=>({item,index})).filter(({item})=>(r==='all'||item.rating===r)&&item.keyword.toLocaleLowerCase().includes(q));}
function list(){
  const rows=filtered();page=Math.min(page,Math.max(0,Math.ceil(rows.length/PAGE_SIZE)-1));
  $('list').replaceChildren();
  if(!rows.length){const p=document.createElement('p');p.className='empty';p.textContent='暂无符合条件的关键词';$('list').append(p);}
  for(const {item,index} of rows.slice(page*PAGE_SIZE,(page+1)*PAGE_SIZE)){
    const button=document.createElement('button');button.className='item'+(index===state.current?' selected':'');button.setAttribute('aria-current',String(index===state.current));
    const wordgroup=document.createElement('span');wordgroup.className='wordgroup';const word=document.createElement('span');word.className='word';word.textContent=item.keyword;wordgroup.append(word);if(state.translateEnabled&&translations[item.keyword.toLowerCase()]){const zh=document.createElement('span');zh.className='translated';zh.textContent=translations[item.keyword.toLowerCase()];wordgroup.append(zh);}
    const badge=document.createElement('span');badge.className='badge '+item.rating;badge.textContent=C.labels[item.rating];button.append(wordgroup,badge);
    button.addEventListener('click',()=>run(async()=>{state.current=index;render();await save();status('已选中关键词，点击搜索查看商品');}));$('list').append(button);
  }
  $('page').textContent=`${rows.length} 词 · ${page+1} / ${Math.max(1,Math.ceil(rows.length/PAGE_SIZE))} 页`;
  $('pagePrev').disabled=page===0;$('pageNext').disabled=(page+1)*PAGE_SIZE>=rows.length;
}
function render(){
  const item=current(),counts={unrated:0,high:0,low:0,none:0};for(const x of state.items)counts[x.rating]++;
  const done=state.items.length-counts.unrated, percent=state.items.length?Math.round(done/state.items.length*100):0;
  $('count').textContent=`已标注 ${done} / ${state.items.length} 个`;$('percent').textContent=percent+'%';$('progress').value=percent;
  $('stats').textContent=`高相关 ${counts.high}　低相关 ${counts.low}　不相关 ${counts.none}　待处理 ${counts.unrated}`;
  $('keyword').textContent=item?.keyword||'先导入一组关键词';$('position').textContent=item?`${state.current+1} / ${state.items.length}`:'—';
  $('badge').textContent=C.labels[item?.rating||'unrated'];$('badge').className='badge '+(item?.rating||'unrated');$('note').value=item?.note||'';
  $('site').value=state.site;$('autoNext').checked=state.autoNext;$('translateEnabled').checked=state.translateEnabled;updateTranslation();
  for(const id of ['search','previous','next','reset','pending','note','export','clear'])$(id).disabled=!item;
  $('previous').disabled=!item||state.current===0;$('next').disabled=!item||state.current===state.items.length-1;
  for(const b of document.querySelectorAll('[data-rating]')){b.disabled=!item;b.setAttribute('aria-pressed',String(item?.rating===b.dataset.rating));}
  list();
  if(item&&state.translateEnabled) translateKeyword(item.keyword).catch(()=>{});
}
async function run(fn){if(busy)return;busy=true;try{await fn();}catch(e){status('操作失败：'+e.message+'。请重试；如保存失败，请先导出备份。',true);}finally{busy=false;}}
async function search(){
  if(!current())return;
  const url=C.searchURL(state.site,current().keyword);
  if(searchTab!==null){
    let exists=true;try{await chrome.tabs.get(searchTab);}catch{exists=false;}
    if(exists){await chrome.tabs.update(searchTab,{url,active:true});status('正在搜索：'+current().keyword);return;}
  }
  const tab=await chrome.tabs.create({url,active:true});searchTab=tab.id;status('正在搜索：'+current().keyword);
}
async function move(index,open=true){if(index<0||index>=state.items.length)return;state.current=index;render();await save();if(open)await search();}
async function rate(rating){
  const item=current();if(!item)return;
  item.rating=rating;item.updatedAt=new Date().toISOString();render();await save();
  status('已保存：'+C.labels[rating]);
  if(state.autoNext&&rating!=='unrated'){
    const i=C.nextUnrated(state.items,state.current);
    if(i>=0)await move(i);else status('全部关键词已标注完成，可以导出结果。');
  }
}
function bind(id,fn){$(id).addEventListener('click',()=>run(fn));}
async function init(){
  for(const [label,value] of Object.entries(C.sites)){const o=document.createElement('option');o.value=value;o.textContent=label;$('site').append(o);}
  const {workspace,keywordTranslations}=await chrome.storage.local.get(['workspace','keywordTranslations']);
  if(keywordTranslations&&typeof keywordTranslations==='object'&&!Array.isArray(keywordTranslations)) translations=keywordTranslations;
  if(workspace){
    if(!Array.isArray(workspace.items)||workspace.items.some(x=>typeof x.keyword!=='string'||!C.labels[x.rating]))throw new Error('本地数据格式异常');
    state={...state,...workspace};state.current=Math.max(0,Math.min(state.current,state.items.length-1));
    if(!Object.values(C.sites).includes(state.site))state.site='www.amazon.com';
  }
  $('importBox').open=!state.items.length;
  bind('import',async()=>{
    const words=C.parse($('input').value);if(!words.length){status('请先粘贴关键词');return;}
    const seen=new Set(state.items.map(x=>x.keyword.toLocaleLowerCase()));const fresh=words.filter(w=>!seen.has(w.toLocaleLowerCase()));
    if(state.items.length+fresh.length>50000)throw new Error('单个列表最多支持 50,000 个关键词，请分批处理');
    state.items.push(...fresh.map(keyword=>({keyword,rating:'unrated',note:'',updatedAt:''})));render();await save();$('input').value='';$('importBox').open=false;status(`已添加 ${fresh.length} 个关键词，重复项已跳过`);
  });
  bind('search',search);bind('previous',()=>move(state.current-1));bind('next',()=>move(state.current+1));
  bind('pending',async()=>{const i=C.nextUnrated(state.items,state.current);if(i>=0)await move(i);else status('没有未标注的关键词');});
  bind('reset',()=>rate('unrated'));
  for(const b of document.querySelectorAll('[data-rating]'))b.addEventListener('click',()=>run(()=>rate(b.dataset.rating)));
  $('note').addEventListener('input',()=>{if(current()){current().note=$('note').value;current().updatedAt=new Date().toISOString();save().then(()=>status('备注已保存')).catch(e=>status('备注保存失败：'+e.message,true));}});
  $('site').addEventListener('change',()=>run(async()=>{state.site=$('site').value;await save();status('已切换站点；已有关键词等级保留，点击搜索刷新结果');}));
  $('translateEnabled').addEventListener('change',()=>run(async()=>{state.translateEnabled=$('translateEnabled').checked;render();await save();}));
  bind('retryTranslate',async()=>{const item=current();if(!item)return;delete translations[item.keyword.toLowerCase()];await persistTranslations();await translateKeyword(item.keyword);});
  bind('translatePage',async()=>{if(!state.items.length){status('请先导入关键词');return;}if(!state.translateEnabled){status('请先开启自动中文翻译');return;}const batch=filtered().slice(page*PAGE_SIZE,(page+1)*PAGE_SIZE);let ok=0;for(const {item} of batch){if(translations[item.keyword.toLowerCase()]){ok++;continue;}await translateKeyword(item.keyword,false);if(translations[item.keyword.toLowerCase()])ok++;}list();status(`本页翻译完成：${ok} / ${batch.length}（失败可重试）`);});
  $('autoNext').addEventListener('change',()=>run(async()=>{state.autoNext=$('autoNext').checked;await save();}));
  for(const id of ['filter','filterText'])$(id).addEventListener('input',()=>{page=0;list();});
  bind('pagePrev',async()=>{page--;list();});bind('pageNext',async()=>{page++;list();});
  bind('export',async()=>{
    const csv='\uFEFF'+[['关键词','中文翻译','相关性','备注','站点','更新时间'],...state.items.map(x=>[x.keyword,translations[x.keyword.toLowerCase()]||'',C.labels[x.rating],x.note,state.site,x.updatedAt])].map(row=>row.map(C.cell).join(',')).join('\r\n');
    const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));
    const a=document.createElement('a');a.href=url;a.download=`amazon-keywords-${new Date().toISOString().slice(0,10)}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);status('已导出全部关键词及标注');
  });
  bind('clear',async()=>{if(!confirm('确定清空所有关键词、等级和备注？此操作不能撤销，请先导出 CSV。'))return;state.items=[];state.current=0;page=0;render();await save();$('importBox').open=true;status('列表已清空');});
  document.addEventListener('keydown',e=>{if(e.ctrlKey||e.altKey||e.metaKey||e.repeat||e.target.matches('input,textarea,select,button')||e.target.isContentEditable)return;const r={'1':'high','2':'low','3':'none'}[e.key];if(r){e.preventDefault();run(()=>rate(r));}});
  render();status('本地数据已就绪；翻译需联网');
}
init().catch(e=>{status('初始化失败：'+e.message,true);document.querySelectorAll('button,input,textarea,select').forEach(el=>el.disabled=true);});

// Translation state is independent from ratings and notes, so errors never interrupt screening.
function updateTranslation(){
  const item=current(), el=$('translation');
  if(!item){el.textContent='导入关键词后显示中文释义';el.className='translation muted';return;}
  if(!state.translateEnabled){el.textContent='翻译已关闭';el.className='translation muted';return;}
  const result=translations[item.keyword.toLowerCase()];
  el.textContent=result||'正在获取中文释义…';el.className='translation'+(result?'':' muted');
}
async function persistTranslations(){
  const keys=Object.keys(translations);
  if(keys.length>3000) for(const k of keys.slice(0,keys.length-3000))delete translations[k];
  await chrome.storage.local.set({keywordTranslations:translations});
}
async function translateKeyword(keyword,refresh=true){
  if(!state.translateEnabled)return;
  const key=keyword.toLowerCase();
  if(translations[key]){if(refresh){updateTranslation();list();}return;}
  // Serial requests avoid flooding the free remote service.
  const task=async()=>{
    if(translations[key]||!state.translateEnabled)return;
    try{
      const response=await chrome.runtime.sendMessage({type:'TRANSLATE_KEYWORD',keyword});
      if(!response?.translation)throw new Error(response?.error||'翻译服务不可用');
      translations[key]=response.translation;
      await persistTranslations();
      if(refresh){if(current()?.keyword.toLowerCase()===key)updateTranslation();list();}
    }catch(e){
      if(refresh&&current()?.keyword.toLowerCase()===key){const el=$('translation');el.textContent='翻译暂不可用（'+e.message+'），可点击重新翻译';el.className='translation failed';}
    }
  };
  translateQueue=translateQueue.catch(()=>{}).then(task);
  return translateQueue;
}
