const $=id=>document.getElementById(id),send=msg=>chrome.runtime.sendMessage(msg);
const parse=text=>[...new Set((text||'').split(/\r?\n/).map(s=>s.trim()).filter(s=>/^https:\/\/(?:www\.)?amazon\.com\/(?:dp|gp\/product)\/[A-Z0-9]{10}/i.test(s)))];
const q=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
let state;
function display(s){
 state=s; const labels={idle:'未开始',running:'运行中',paused:'暂停',done:'完成'};
 $('status').textContent=`${labels[s.status]||s.status} · ${s.index}/${s.links.length}`;$('message').textContent=s.message||'';
 $('progress').value=s.links.length?100*s.index/s.links.length:0;
 const statuses={};(s.results||[]).forEach(r=>statuses[r.status]=(statuses[r.status]||0)+1);
 $('summary').textContent=Object.entries(statuses).map(([k,v])=>`${k}: ${v}`).join(' | ');
 $('testInfo').textContent=s.testResult?JSON.stringify(s.testResult,null,2):'尚未测试';
 $('start').disabled=s.status==='running';$('pause').disabled=s.status!=='running';$('resume').disabled=s.status!=='paused';$('skip').disabled=s.status!=='paused';$('clear').disabled=s.status==='running';$('export').disabled=!(s.results||[]).length;
}
async function refresh(){try{display((await send({type:'GET'})).state)}catch(e){$('message').textContent=e.message}}
$('test').onclick=async()=>{const r=await send({type:'TEST_CURRENT'});if(r.error)alert(r.error);await refresh()};
$('urls').oninput=()=>{$('count').textContent=parse($('urls').value).length+' 个'};
$('csvFile').onchange=async e=>{
 const f=e.target.files[0];if(!f)return;const text=await f.text();
 const rows=text.replace(/^\uFEFF/,'').split(/\r?\n/).map(x=>x.split(','));
 const first=rows[0].map(x=>x.trim().replace(/^"|"$/g,'').toLowerCase());const idx=first.findIndex(x=>['url','link','product url','商品链接','详情页链接'].includes(x));
 const vals=rows.slice(idx>=0?1:0).map(row=>row[idx>=0?idx:0]||'');$('urls').value=parse(vals.join('\n')).join('\n');$('urls').dispatchEvent(new Event('input'));
};
$('start').onclick=async()=>{const urls=parse($('urls').value);if(!urls.length)return alert('请输入至少一个有效Amazon商品详情页链接');const r=await send({type:'START',urls,delaySeconds:Math.max(4,Number($('delay').value)||7)});if(r.error)alert(r.error);await refresh()};
$('pause').onclick=async()=>{await send({type:'PAUSE'});await refresh()};
$('resume').onclick=async()=>{const r=await send({type:'RESUME'});if(r.error)alert(r.error);await refresh()};
$('skip').onclick=async()=>{if(!confirm('跳过当前链接并继续下一条？'))return;const r=await send({type:'SKIP'});if(r.error)alert(r.error);await refresh()};
$('clear').onclick=async()=>{const r=await send({type:'CLEAR'});if(r.error)alert(r.error);await refresh()};
$('export').onclick=()=>{
 if(!state?.results?.length)return;
 const maxBullets=Math.max(0,...state.results.map(r=>(r.bullets||[]).length));
 const head=['Requested URL','Requested ASIN','Actual URL','Actual URL ASIN','DOM ASIN','Variant Warning','Title','Price USD','List Price USD','Rating (out of 5)','Rating/Review Count','Bullet Count',...Array.from({length:maxBullets},(_,i)=>`Bullet ${i+1}`),'All Bullets','Status','Detail'];
 const rows=state.results.map(r=>[r.requestedUrl||'',r.requestedAsin||r.asin,r.url||'',r.urlAsin||'',r.domAsin||'',r.variantWarning||'',r.title,r.price||'',r.listPrice||'',r.rating||'',r.reviewCount||'',(r.bullets||[]).length,...Array.from({length:maxBullets},(_,i)=>r.bullets?.[i]||''),(r.bullets||[]).join(' | '),r.status,r.detail]);
 const content='\uFEFF'+[head,...rows].map(row=>row.map(q).join(',')).join('\r\n');
 const url=URL.createObjectURL(new Blob([content],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='amazon_listing_v7_price_rating_reviews.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),3000);
};
refresh();setInterval(refresh,1200);
