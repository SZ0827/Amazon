Amazon Listing Collector v7.0

新增字段：Price USD（页面售价）、List Price USD（如有划线价）、Rating（1-5）、Rating/Review Count。
保留URL输入、动态Bullet条数、后台非活动标签顺序采集、异常通知、CSV导出。
安装：chrome://extensions -> 开发者模式 -> 加载已解压的扩展程序 -> 选择包含manifest.json的本目录。
售价/划线价、评论数量和评分可能因区域、登录状态、商品变体或页面布局而缺失，请复核异常值。价格不含税与运费，不保证Buy Box。未识别时留空，不人工猜测。
