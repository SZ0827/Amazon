const KEY='bulletCollectorV6';
chrome.action.onClicked.addListener(async()=>{
 const target=chrome.runtime.getURL('dashboard.html');
 const wins=await chrome.windows.getAll({populate:true});
 const existing=wins.find(w=>w.tabs?.some(t=>t.url===target));
 if(existing){await chrome.windows.update(existing.id,{focused:true});return;}
 await chrome.windows.create({url:target,type:'popup',width:690,height:850,focused:true});
});
function cleanUrl(raw){
 try{
 const u=new URL(String(raw||'').trim());
 if(!/^https:$/.test(u.protocol)||!/(^|\.)amazon\.com$/i.test(u.hostname))return null;
 const m=u.pathname.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})(?:\/|$)/i);
 if(!m)return null;
 return {url:`https://www.amazon.com/dp/${m[1].toUpperCase()}`,asin:m[1].toUpperCase(),original:String(raw).trim()};
 }catch{return null;}
}
const blank=()=>({links:[],results:[],index:0,status:'idle',message:'',delaySeconds:7,blockedAsin:null});
let running=false, stopRequested=false;
async function notifyError(title,message){
 try {await chrome.notifications.create({type:'basic',iconUrl:'icon128.png',title,message:message.slice(0,300),priority:2,requireInteraction:true});}
 catch(e){console.warn('Notification unavailable:',e)}
 // Keep dashboard updated without taking focus away from user's current window.
}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function getState(){return (await chrome.storage.local.get(KEY))[KEY]||blank()}
async function setState(s){await chrome.storage.local.set({[KEY]:s})}
function extractor(){
 const norm=s=>String(s||'').replace(/\s+/g,' ').trim();
 const body=document.body?.innerText||'';
 const challenge=/validateCaptcha|\/errors\/validateCaptcha|\/ap\/signin/i.test(location.href)||/enter the characters you see below|type the characters you see in this image|verify you are a human|sorry, we just need to make sure you're not a robot/i.test(body.slice(0,4000));
 const title=norm(document.querySelector('#productTitle')?.textContent || document.querySelector('meta[property="og:title"]')?.content);
 const domAsin=norm(document.querySelector('input#ASIN')?.value||document.querySelector('input[name="ASIN"]')?.value).toUpperCase();
 const urlAsin=norm((location.pathname.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/i)||[])[1]).toUpperCase();
 const pageAsin=urlAsin||domAsin;
 const containers=['#feature-bullets ul li span.a-list-item','#feature-bullets ul li .a-list-item','#feature-bullets li .a-list-item','#feature-bullets li','[data-feature-name="featurebullets"] li'];
 let bullets=[];
 for(const selector of containers){
  const candidates=[...document.querySelectorAll(selector)].map(el=>norm(el.innerText||el.textContent));
  const usable=candidates.filter(t=>t.length>=12&&!/^(?:make sure this fits|see more product details|report an issue with this product|customer reviews|visit the .* store)$/i.test(t));
  if(usable.length){bullets=[...new Set(usable)];break}
 }
 // Amazon may show multiple prices: prefer the primary detail-page purchase price.
 const txt=el=>norm(el?.innerText||el?.textContent||'');
 const firstText=(selectors)=>{
  for(const selector of selectors){
   for(const el of document.querySelectorAll(selector)){
    const t=txt(el);
    if(t)return t;
   }
  }
  return '';
 };
 const money=s=>{
  const m=String(s||'').match(/(?:US\s*)?\$\s*([\d,]+(?:\.\d{2})?)/i);
  return m?'$'+m[1].replace(/,/g,''):'';
 };
 const priceSelectors=[
  '#corePrice_feature_div .priceToPay .a-offscreen',
  '#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen',
  '#corePrice_feature_div .a-price .a-offscreen',
  '#corePriceDisplay_desktop_feature_div .a-price .a-offscreen',
  '#apex_desktop .priceToPay .a-offscreen',
  '#newBuyBoxPrice',
  '#priceblock_ourprice', '#priceblock_dealprice',
  '#corePrice_feature_div .a-price-whole',
  '#buybox .a-price .a-offscreen'
 ];
 const price=money(firstText(priceSelectors));
 const listPrice=money(firstText([
  '#corePriceDisplay_desktop_feature_div .basisPrice .a-offscreen',
  '#corePrice_feature_div .basisPrice .a-offscreen',
  '.a-text-price[data-a-strike="true"] .a-offscreen',
  '#listPrice', '#priceblock_listprice'
 ]));
 const ratingText=firstText([
  '#acrPopover [class*="a-icon-alt"]',
  '#averageCustomerReviews .a-icon-alt',
  '[data-hook="rating-out-of-text"]',
  '#averageCustomerReviews span[data-hook="rating-out-of-text"]'
 ]);
 const ratingMatch=ratingText.match(/(\d+(?:[.,]\d+)?)\s*(?:out of\s*5|von\s*5|sur\s*5|星|颗星)/i);
 const rating=ratingMatch?ratingMatch[1].replace(',','.'):'';
 const reviewText=firstText([
  '#acrCustomerReviewText',
  '#averageCustomerReviews #acrCustomerReviewText',
  '[data-hook="total-review-count"]'
 ]);
 const countMatch=reviewText.replace(/\u00a0/g,' ').match(/([\d,]+)\s*(?:ratings?|reviews?|global ratings?|customer reviews?|条评论|个评分)?/i);
 const reviewCount=countMatch?countMatch[1].replace(/,/g,''):'';
 const htmlLang=document.documentElement.lang||'';
 let status='success', detail='';
 if(challenge){status='challenge';detail='Amazon 验证码或登录/机器人验证';bullets=[]}
 else if(!title){status='page_error';detail='未获取商品标题：页面未完全加载、访问受限或页面结构变化'}
 else if(!bullets.length){status='no_bullets';detail='已找到标题，但页面上没有识别到五点描述'}

 return {asin:pageAsin,actualAsin:pageAsin,urlAsin,domAsin,title,bullets,price,listPrice,rating,reviewCount,priceText:firstText(priceSelectors),ratingText,reviewText,status,detail,url:location.href,debug:{pageTitle:document.title,language:htmlLang,foundBulletContainer:!!document.querySelector('#feature-bullets')}};
}
async function extractTab(tabId,expectedAsin){
 let result;
 try { const out=await chrome.scripting.executeScript({target:{tabId},func:extractor});result=out?.[0]?.result; }
 catch(e){return {asin:expectedAsin||'',title:'',bullets:[],status:'script_error',detail:e.message,url:''}}
 if(!result)return {asin:expectedAsin||'',title:'',bullets:[],status:'script_error',detail:'脚本没有返回结果',url:''};
 result.requestedAsin=expectedAsin||result.asin;
 // Never silently attribute another variant's copy to the requested ASIN.
 if(expectedAsin && result.status==='success' && result.urlAsin && result.urlAsin!==expectedAsin){
   result.status='variant_redirect';
   result.detail=`请求 ${expectedAsin}；页面DOM ASIN ${result.domAsin||'未识别'}；URL ASIN ${result.urlAsin||'未识别'}。保留实际页面五点并标为变体，不等同于请求ASIN。`;
 }
 if(expectedAsin && result.status==='success' && result.domAsin && result.domAsin!==expectedAsin){result.variantWarning=`页面变体字段 ${result.domAsin} 与请求ASIN ${expectedAsin} 不同，请复核`; }
 result.asin=expectedAsin||result.asin;
 return result;
}
async function waitForTab(tabId,seconds=55){
 for(let i=0;i<seconds;i++){
  const t=await chrome.tabs.get(tabId).catch(()=>null);
  if(!t)throw Error('标签页已关闭');
  if(t.status==='complete')return;
  await sleep(1000);
 }
 throw Error('页面加载超时');
}
async function readWithRetries(tabId,asin){
 let res;
 for(let i=0;i<5;i++){
  res=await extractTab(tabId,asin);
  if(!['page_error','script_error','no_bullets'].includes(res.status))break;
  await sleep(1800);
 }
 return res;
}
async function batch(){
 if(running)return;
 running=true;stopRequested=false;
 try{
  let s=await getState();s.status='running';s.message='静默顺序采集：商品页在后台打开，不切换当前标签页';await setState(s);
  while(s.index<s.links.length && !stopRequested){
   const item=s.links[s.index],asin=item.asin,url=item.url;
   let tab;
   try{
    tab=await chrome.tabs.create({url,active:false});
    await waitForTab(tab.id);
    await sleep(2300);
    const result=await readWithRetries(tab.id,asin);
    result.requestedUrl=item.original;
    if(!['success','variant_redirect'].includes(result.status)){
      s.status='paused';s.blockedAsin=asin;s.message=`${asin} 未成功（${result.status}）：${result.detail||'未知原因'}。停止队列，当前页保留。解决问题后点击「重试本条」，或者「跳过本条」。`;await setState(s);await notifyError('Amazon采集暂停',s.message);return;
    }
    s.blockedAsin=null;s.results.push(result);s.index++;
    s.message=`已完成 ${s.index}/${s.links.length}；最近一条: ${result.status}${result.detail?' - '+result.detail:''}`;
    await setState(s);
    await chrome.tabs.remove(tab.id).catch(()=>{});
   }catch(e){
    s.status='paused';s.blockedAsin=asin;
    s.message=`${asin} 失败：${e.message}。已停止队列，可重试或跳过。`;await setState(s);await notifyError('Amazon采集异常',s.message);
    return;
   }
   if(s.index<s.links.length&&!stopRequested)await sleep(Math.max(4,Number(s.delaySeconds)||7)*1000);
  }
  s.status=stopRequested?'paused':'done';s.message=stopRequested?'用户已暂停':'已处理完成';await setState(s);
 }catch(e){let s=await getState();s.status='paused';s.message='运行异常：'+e.message;await setState(s);await notifyError('Amazon采集异常',s.message)}
 finally{running=false}
}
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
 (async()=>{
  if(msg.type==='GET')return {state:await getState()};
  if(msg.type==='TEST_CURRENT'){
   const tabs=await chrome.tabs.query({url:'https://www.amazon.com/*'});
   const tab=tabs.filter(t=>/\/(dp|gp\/product)\//.test(t.url||'')).slice(-1)[0];if(!tab?.url?.startsWith('https://www.amazon.com/'))return {error:'请先打开 amazon.com 的商品详情页，再点击测试'};
   const result=await readWithRetries(tab.id,'');
   let s=await getState();s.testResult=result; s.message=`单页测试：${result.status} ${result.detail||''}`;await setState(s);
   return {result};
  }
  if(msg.type==='START'){
   if(running)return {error:'任务正在运行'};
   const links=[...new Map((msg.urls||[]).map(cleanUrl).filter(Boolean).map(x=>[x.url,x])).values()];
   if(!links.length)return {error:'请输入至少一个有效的Amazon美国站商品详情页链接'};
   await setState({...blank(),links,status:'running',delaySeconds:msg.delaySeconds||7,message:'初始化'});batch();return {ok:true};
  }
  if(msg.type==='PAUSE'){stopRequested=true;return {ok:true}};
  if(msg.type==='SKIP'){
   if(running)return {error:'请等待当前采集停止'};
   const s=await getState();if(s.status!=='paused'||s.index>=s.links.length)return {error:'当前没有可跳过的商品'};
   const item=s.links[s.index],asin=item.asin;s.results.push({asin,requestedUrl:item.original,title:'',bullets:[],status:'skipped',detail:'用户选择跳过',url:`https://www.amazon.com/dp/${asin}`});s.index++;s.blockedAsin=null;await setState(s);
   if(s.index<s.links.length)batch();else{ s.status='done';s.message='全部链接处理完成';await setState(s) }return {ok:true};
  }
  if(msg.type==='RESUME'){
   if(running)return {error:'正在运行'};
   const s=await getState();if(s.index>=s.links.length)return {error:'没有剩余ASIN'};
   batch();return {ok:true};
  }
  if(msg.type==='CLEAR'){if(running)return {error:'请暂停任务后清空'};await setState(blank());return {ok:true}}
 })().then(reply).catch(e=>reply({error:e.message}));return true;
});
